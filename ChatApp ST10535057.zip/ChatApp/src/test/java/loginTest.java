/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import com.mycompany.chatapp.login;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author khazi
 */

public class loginTest {
    
 login user = new login();
   
    @Test
    public void testUsernameIncorrect() {
        String result = user.registerUser("kyle!!!!!!!!!", "Ch@&sec@ke99!", "+27838996876");
        
        assertEquals("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.", result);
    }
    
    @Test
    public void testPasswordIncorrect() {
        String result = user.registerUser("kyl_1", "password", "+27838996876");
        
        assertEquals("Password is not correctly formatted; please ensure that the password contains atleast eight characters, a capital letter, a number, and a special character.", result);
    }
    
    @Test
    public void testPhoneIncorrect() {
        String result = user.registerUser("kyl_1", "Ch@&sec@ke99!", "08996053");
        
        assertEquals("Cell phone number incorrectly formatted or does not contain international code.", result);
    }
    
    @Test
    public void testRegisterSuccess() {
        String result = user.registerUser("kyl_1", "Ch@&sec@ke99!", "+27838996876");
        
        assertEquals("User has registered successfully.", result);
    }
    
    @Test
    public void testLoginMessageSuccess() {
        user.registerUser("kyl_1", "Ch@&sec@ke99!", "+27838996876");
        
        boolean login = user.LoginUser("kyl_1", "Ch@&sec@ke99!");
        String message = user.returnLoginStatus(login);
        
        assertEquals("Welcome kyl_1 it is great to see you again.", message);
    }
    
    @Test
    public void testLoginMessageFail() {
        user.registerUser("kyl_1", "Ch@&sec@ke99!", "+27838996876");
        
        boolean login = user.LoginUser("kyl_1", "wrong");
        String message = user.returnLoginStatus(login);
        
        assertEquals("Username or password incorrect, please try again.", message);
    }
    

    // ============================
    // TABLE 2 (assertTrue / False)
    // ============================

    @Test
    public void testUsernameValid() {
        assertTrue(user.checkUserName("kyl_1"));
    }
    
    @Test
    public void testUsernameInvalid() {
        assertFalse(user.checkUserName("kyle!!!!!!!!!"));
    }
    
    @Test
    public void testPasswordValid() {
        assertTrue(user.checkPasswordComplexity("Ch@&sec@ke99!"));
    }
    
    @Test
    public void testPasswordInvalid() {
        assertFalse(user.checkPasswordComplexity("password"));
    }
    
    @Test
    public void testPhoneValid() {
        assertTrue(user.checkphoneNumber("+27838996876"));
    }
    
    @Test
    public void testPhoneInvalid() {
        assertFalse(user.checkphoneNumber("08996053"));
    }
    
    @Test
    public void testLoginSuccess() {
        user.registerUser("kyl_1", "Ch@&sec@ke99!", "+27838996876");
        
        assertTrue(user.LoginUser("kyl_1", "Ch@&sec@ke99!"));
    }
    
    @Test
    public void testLoginFail() {
        user.registerUser("kyl_1", "Ch@&sec@ke99!", "+27838996876");
        
        assertFalse(user.LoginUser("kyl_1", "wrongpass"));
    }
}