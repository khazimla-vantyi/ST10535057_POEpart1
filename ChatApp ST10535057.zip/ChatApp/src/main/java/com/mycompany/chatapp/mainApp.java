/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp;

import java.util.Scanner;

/**
 *
 * @author khazi
 */

public class mainApp {
    
    public static void main(String[] args){
        
        Scanner input = new Scanner(System.in);
        
        login login = new login();
        
        //REGISTRATION
        System.out.println("=== USER REGISTRATION===");
        
        System.out.print("Enter a username: ");
        String username = input.nextLine();
        
        System.out.print("Enter a password: ");
        String password = input.nextLine();
        
        
       System.out.print("Enter your South African phone number (+27....): ");
       String phone = input.nextLine();
       
       
       String response = login.registerUser(username, password, phone);
       
       System.out.println(response);
       
       
       //LOGIN
       System.out.println("\n=== USER LOGIN===");
       
       System.out.println("Enter your username: ");
       String loginUsername = input.nextLine();
       
       System.out.println("Enter your password: ");
       String loginPassword = input.nextLine();
       
       boolean loggedIn = login.LoginUser(loginUsername, loginPassword);
       
        String loginMessage = login.returnLoginStatus(loggedIn);
        System.out.println(loginMessage);
    }
}